package com.example.todoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    public static ToDOAdapter toDOAdapter;
    private OrmliteHelper ormliteHelper;
    public static List<TodoModelDTO> todolist = new ArrayList<>();

    private FloatingActionButton floatingActionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ormliteHelper = new OrmliteHelper(this);

        recyclerView = findViewById(R.id.todolist);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        floatingActionButton = findViewById(R.id.floatingActionButton);

        try {
            todolist = ormliteHelper.getAll(TodoModelDTO.class);
        } catch (SQLException e) {
            Toast.makeText(this, "Database error", Toast.LENGTH_SHORT).show();
        }
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                final View customLayout = inflater.inflate(R.layout.dialog_add_todo, null);

                EditText etDate = customLayout.findViewById(R.id.etTodoDate);
                etDate.setInputType(InputType.TYPE_NULL);
                etDate.setOnClickListener(v -> {
                    final Calendar calendar = Calendar.getInstance();
                    int year = calendar.get(Calendar.YEAR);
                    int month = calendar.get(Calendar.MONTH);
                    int day = calendar.get(Calendar.DAY_OF_MONTH);
                    new DatePickerDialog(MainActivity.this, (view1, year1, monthOfYear, dayOfMonth) -> {
                        String formattedDate = String.format("%02d/%02d/%04d", dayOfMonth, (monthOfYear + 1), year1);
                        etDate.setText(formattedDate);
                    }, year, month, day).show();
                });

                builder.setView(customLayout)
                        .setPositiveButton("Add", (dialog, id) -> {
                            // Extract your data here from customLayout's EditTexts and handle as needed
                            EditText etTitle = customLayout.findViewById(R.id.etTodoTitle);
                            EditText etDescription = customLayout.findViewById(R.id.etTodoDescription);
                            String title = etTitle.getText().toString();
                            String description = etDescription.getText().toString();
                            String date = etDate.getText().toString();


                            // Check if any of the fields are empty
                            if (title.trim().isEmpty() || description.trim().isEmpty() || date.trim().isEmpty()) {
                                // Show an error message to the user
                                Toast.makeText(MainActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                                return; // Stop further execution
                            }

                            //Create object model
                            TodoModelDTO todoModelDTO = new TodoModelDTO();
                            todoModelDTO.setTitle(title);
                            todoModelDTO.setDescription(description);
                            todoModelDTO.setDate(date);
                            todoModelDTO.setDone(false);

                            try {
                                ormliteHelper.createOrUpdate(todoModelDTO);
                                todolist = ormliteHelper.getAll(TodoModelDTO.class);
                                toDOAdapter = new ToDOAdapter(MainActivity.this,todolist);
                                recyclerView.setAdapter(toDOAdapter);
                                toDOAdapter.notifyDataSetChanged();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }

                        })
                        .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        toDOAdapter = new ToDOAdapter(this,todolist);
        recyclerView.setAdapter(toDOAdapter);
        toDOAdapter.notifyDataSetChanged();


    }

}